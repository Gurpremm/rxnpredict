library('Metrics')

library('randomForest')

library('ggplot2')

library('ggthemes')

library('dplyr')

#set random seed

set.seed(101)

#loading dataset

data<-read.csv("/Users/gurprem/Downloads/rxnpredict/gurprem_chem.csv",stringsAsFactors= T)#checking dimensions of data

dim(data)
#specifying outcome variable as factor

#data$yield<-as.factor(data$yield)

data$Time<-NULL

#dividing the dataset into train and test

train<-data[1:440,]

test<-data[441:640,]

#applying Random Forest

model_rf <- randomForest(yield ~ alcohol_.C1_electrostatic_charge,	alcohol_.C1_exposed_area,	alcohol_electronegativity,	alcohol_primary,	alcohol_secondary,	alcohol_tertiary,	alcohol_cyclic,	alcohol_4.membered_ring,	alcohol_5.membered_ring,	alcohol_6.membered_ring,	alcohol_7.membered_ring,	alcohol_benzylic,	alcohol_allylic,	alcohol_homobenzylic,	alcohol_homoallylic,	alcohol_alpha.carbonyl,	alcohol_beta_carbonyl,	alcohol_hemiacetal,	alcohol_alpha.amino, base_.N1_exposed_area,	sulfonyl_fluoride_.S1_electrostatic_charge,	sulfonyl_fluoride_.F1_electrostatic_charge,	sulfonyl_fluoride_.O1_electrostatic_charge , data = train)

model_rf <- randomForest(yield ~ . , data = train, ntree=50)
preds<-predict(model_rf,test)
table(preds)

#test.pred.forest <- predict(rf,test)
RMSE.forest <- sqrt(mean((preds-test$yield)^2))
RMSE.forest
library(miscTools)
r2 = r2_score(test.yield, rf.predict(test[cols]))
importance(model_rf)

model_rf2 <- randomForest(yield ~ alcohol_.C1_electrostatic_charge, alcohol_.C1_exposed_area, alcohol_electronegativity,alcohol_primary ,alcohol_secondary,alcohol_tertiary,alcohol_cyclic,alcohol_4.membered_ring,alcohol_5.membered_ring,alcohol_6.membered_ring, alcohol_7.membered_ring, alcohol_benzylic,alcohol_alpha.amino,base_.N1_exposed_area,sulfonyl_fluoride_.S1_electrostatic_charge,sulfonyl_fluoride_.F1_electrostatic_charge, sulfonyl_fluoride_.O1_electrostatic_charge, data= train)
