
library(rpart)              # CART algorithm for decision trees
library(partykit)           # Plotting trees
library(gbm)   
library(tidyverse)
library(xgboost)
pacman::p_load(ggplot2, 
               ModelMetrics,
               scales)
pacman::p_load(caret,randomForest)
library(doParallel)
# Set the working directory to the location of the rxnpredict folder.
setwd("/Users/gurprem/Downloads/rxnpredict")

# ============================================================================
# Load descriptor and yield data and prepare data for modeling.
# ============================================================================

# Load user-created table containing reaction descriptors.
descriptor.table <- read.csv("R_input/descriptor_table.csv", header=TRUE)

# Scale the descriptor data. Scale parameters are saved in descriptor.data.
descriptor.data <- scale(descriptor.table)
descriptor.scaled <- as.data.frame(descriptor.data)

# Load user-created yield data.
yield.data <- as.numeric(unlist(read.csv("R_input/observed_yields.csv", header=FALSE, stringsAsFactors=FALSE)))

# Append the yield data to the descriptor table.
descriptor.scaled$yield <- yield.data

# ============================================================================
# Split data and train random forest model.
# ============================================================================

# Split into training and test set (70/30).
set.seed(1751)
size <- round(0.70*nrow(descriptor.scaled))
training <- sample(nrow(descriptor.scaled), size=size, replace=FALSE)
training.scaled <- descriptor.scaled[training,]
test.scaled <- descriptor.scaled[-training,]

# training gbm model

fitControl <- trainControl(method = "repeatedcv", # cv
                           number=10,repeats=3,  # 10  
                           verboseIter = TRUE,returnResamp = "all")

gbmGrid <-  expand.grid(interaction.depth = c(10,12,15),
                        n.trees = seq(700,800),
                        shrinkage = 0.1,
                        n.minobsinnode = c(10,12,14))


gbm_model <- train(yield~., data=training.scaled,  method="gbm",
                   metric='RMSE',trControl = fitControl,bag.fraction=0.5,tuneGrid=gbmGrid)

gbm_model$call
gbm_model$bestTune
library(Metrics)
predict(gbm_model,test.scaled)
rmse(training.scaled$yield,predict(gbm_model,training.scaled))

rmse(test.scaled$yield,predict(gbm_model,test.scaled))

Rsqu <- function(y, yhat) {
  
  mdata <- mean(y)
  
  1 - sum((y-yhat)^2)/(sum((y-mdata)^2))
  
}
Rsqu(training.scaled$yield,predict(gbm_model,training.scaled))

Rsqu(test.scaled$yield,predict(gbm_model,test.scaled))
# Load external test set.
externalset.table <- read.csv("R_input/descriptor_table_external_set.csv", header=TRUE)

# Scale the external set data using the same scaling as for the training and test sets.
externalset.data <- scale(externalset.table,attr(descriptor.data,"scaled:center"),attr(descriptor.data,"scaled:scale"))
externalset.scaled <- as.data.frame(externalset.data)

# Load external set observed yields.
external_obs <- as.numeric(unlist(read.csv("R_input/external_set_observed_yields.csv", header=FALSE, stringsAsFactors=FALSE)))
external_obs.data <- scale(externalset.table,attr(descriptor.data,"scaled:center"),attr(descriptor.data,"scaled:scale"))
external_obs.scaled<- as.data.frame(external_obs.data)

# Append the yield data to the external descriptor table.
externalset.scaled$yield <- external_obs

#dbmatrix form external set
ext_y = externalset.scaled[,'yield']
ext_x = externalset.scaled[, names(externalset.scaled) !='yield']

rmse(external_obs,predict(gbm_model,externalset.scaled))
Rsqu(external_obs,predict(gbm_model,externalset.scaled))
